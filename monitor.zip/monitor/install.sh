#!/bin/bash

set -e

# 配置
INSTALL_DIR="/opt/monitor"
SERVICE_FILE="/etc/systemd/system/monitor.service"
LOCK_FILE="/var/run/monitor.lock"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# 检查root权限
check_root() {
    if [ "$EUID" -ne 0 ]; then
        echo "[ERROR] 请使用root权限运行此脚本"
        echo "用法: sudo ./install.sh"
        exit 1
    fi
}

# 自动清理旧安装（无人值守）
auto_cleanup() {
    echo "[INFO] 清理旧安装..."

    # 停止服务（如果正在运行）
    if systemctl is-active --quiet monitor.service 2>/dev/null; then
        echo "[INFO] 停止旧服务..."
        systemctl stop monitor.service 2>/dev/null || true
        # 等待服务完全停止
        sleep 2
    fi

    # 禁用服务（如果已启用）
    if systemctl is-enabled --quiet monitor.service 2>/dev/null; then
        echo "[INFO] 禁用旧服务..."
        systemctl disable monitor.service 2>/dev/null || true
    fi

    # 删除服务文件
    if [ -f "$SERVICE_FILE" ]; then
        echo "[INFO] 删除旧服务文件..."
        rm -f "$SERVICE_FILE"
    fi

    # 删除安装目录
    if [ -d "$INSTALL_DIR" ]; then
        echo "[INFO] 删除旧安装目录..."
        rm -rf "$INSTALL_DIR"
    fi

    # 删除锁文件
    if [ -f "$LOCK_FILE" ]; then
        echo "[INFO] 删除锁文件..."
        rm -f "$LOCK_FILE"
    fi

    # 删除可能残留的临时文件
    rm -f /tmp/email_*.txt 2>/dev/null || true

    # 重新加载systemd
    systemctl daemon-reload 2>/dev/null || true

    echo "[INFO] 清理完成"
}

# 检查Python3
check_python() {
    echo "[INFO] 检查Python3..."

    if ! command -v python3 &> /dev/null; then
        echo "[INFO] 未找到Python3，正在安装..."
        apt-get update -qq
        apt-get install -y -qq python3 python3-pip

        if ! command -v python3 &> /dev/null; then
            echo "[ERROR] Python3 安装失败"
            exit 1
        fi
    fi

    echo "[INFO] Python3 已就绪"
}

# 安装Python依赖
install_dependencies() {
    echo "[INFO] 安装Python依赖..."

    # 安装pip（如果不存在）
    if ! command -v pip3 &> /dev/null; then
        apt-get install -y -qq python3-pip 2>/dev/null || true
    fi

    # 尝试多种方式安装依赖
    local install_success=false

    # 方式1: 使用 --break-system-packages (Python 3.11+)
    if pip3 install requests watchdog --quiet --break-system-packages 2>/dev/null; then
        install_success=true
    # 方式2: 普通安装
    elif pip3 install requests watchdog --quiet 2>/dev/null; then
        install_success=true
    # 方式3: 使用系统包管理器
    elif apt-get install -y -qq python3-requests python3-watchdog 2>/dev/null; then
        install_success=true
    fi

    if [ "$install_success" = false ]; then
        echo "[WARNING] Python依赖安装可能不完整，请手动检查"
    else
        echo "[INFO] 依赖安装完成"
    fi
}

# 创建安装目录
create_install_dir() {
    echo "[INFO] 创建安装目录..."

    mkdir -p "$INSTALL_DIR"
    chmod 700 "$INSTALL_DIR"
}

# 复制文件
copy_files() {
    echo "[INFO] 复制脚本文件..."

    # 复制主脚本
    if [ -f "$SCRIPT_DIR/monitor.py" ]; then
        cp "$SCRIPT_DIR/monitor.py" "$INSTALL_DIR/monitor.py"
        chmod 600 "$INSTALL_DIR/monitor.py"
    else
        echo "[ERROR] 未找到 monitor.py 文件"
        exit 1
    fi
}

# 安装systemd服务
install_service() {
    echo "[INFO] 安装systemd服务..."

    # 复制服务文件
    if [ -f "$SCRIPT_DIR/monitor.service" ]; then
        cp "$SCRIPT_DIR/monitor.service" "$SERVICE_FILE"
        chmod 644 "$SERVICE_FILE"
    else
        echo "[ERROR] 未找到 monitor.service 文件"
        exit 1
    fi

    # 重新加载systemd
    systemctl daemon-reload
}

# 启动服务
start_service() {
    echo "[INFO] 启动服务..."

    # 启用开机自启动
    systemctl enable monitor.service

    # 启动服务
    systemctl start monitor.service

    # 等待服务启动（增加等待时间）
    sleep 3

    # 检查服务状态
    if systemctl is-active --quiet monitor.service; then
        echo "[INFO] 服务启动成功"
    else
        echo "[WARNING] 服务可能未正常启动"
        echo "[INFO] 请检查: systemctl status monitor.service"
        echo "[INFO] 或查看: journalctl -u monitor.service -n 50"
    fi
}

# 清理安装文件
cleanup_install_files() {
    echo "[INFO] 清理安装文件..."

    # 获取安装包可能的位置（monitor文件夹的上级目录）
    PARENT_DIR="$(dirname "$SCRIPT_DIR")"

    # 删除 monitor.zip（可能在上级目录或当前目录）
    if [ -f "$PARENT_DIR/monitor.zip" ]; then
        rm -f "$PARENT_DIR/monitor.zip"
    fi

    if [ -f "$SCRIPT_DIR/monitor.zip" ]; then
        rm -f "$SCRIPT_DIR/monitor.zip"
    fi

    # 删除解压出来的 monitor 文件夹（即脚本所在目录）
    # 安全检查：确保不会删除重要目录
    if [ -d "$SCRIPT_DIR" ] && \
       [ "$SCRIPT_DIR" != "/" ] && \
       [ "$SCRIPT_DIR" != "/root" ] && \
       [ "$SCRIPT_DIR" != "/home" ] && \
       [ "$SCRIPT_DIR" != "/opt" ] && \
       [ "$SCRIPT_DIR" != "/tmp" ] && \
       [ "$SCRIPT_DIR" != "$INSTALL_DIR" ]; then
        rm -rf "$SCRIPT_DIR"
    fi

    echo "[INFO] 安装文件已清理"
}

# 主函数
main() {
    check_root
    auto_cleanup
    check_python
    install_dependencies
    create_install_dir
    copy_files
    install_service
    start_service
    cleanup_install_files

    echo "[INFO] 安装完成"
}

# 运行主函数
main