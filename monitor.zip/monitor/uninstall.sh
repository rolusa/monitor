#!/bin/bash

set -e

# 配置
INSTALL_DIR="/opt/monitor"
SERVICE_FILE="/etc/systemd/system/monitor.service"
LOCK_FILE="/var/run/monitor.lock"

# 检查root权限
check_root() {
    if [ "$EUID" -ne 0 ]; then
        echo "[ERROR] 请使用root权限运行此脚本"
        exit 1
    fi
}

# 停止服务
stop_service() {
    echo "[INFO] 停止服务..."

    if systemctl is-active --quiet monitor.service 2>/dev/null; then
        systemctl stop monitor.service 2>/dev/null || true
        # 等待服务完全停止
        sleep 2
        echo "[INFO] 服务已停止"
    else
        echo "[INFO] 服务未运行"
    fi
}

# 禁用服务
disable_service() {
    echo "[INFO] 禁用开机自启动..."

    if systemctl is-enabled --quiet monitor.service 2>/dev/null; then
        systemctl disable monitor.service 2>/dev/null || true
        echo "[INFO] 已禁用开机自启动"
    fi
}

# 删除服务文件
remove_service() {
    echo "[INFO] 删除服务文件..."

    if [ -f "$SERVICE_FILE" ]; then
        rm -f "$SERVICE_FILE"
        systemctl daemon-reload 2>/dev/null || true
        echo "[INFO] 服务文件已删除"
    fi
}

# 删除安装目录
remove_files() {
    echo "[INFO] 删除安装目录..."

    if [ -d "$INSTALL_DIR" ]; then
        rm -rf "$INSTALL_DIR"
        echo "[INFO] 安装目录已删除: $INSTALL_DIR"
    fi

    # 删除锁文件
    if [ -f "$LOCK_FILE" ]; then
        rm -f "$LOCK_FILE"
        echo "[INFO] 锁文件已删除"
    fi

    # 删除可能残留的临时文件
    rm -f /tmp/email_*.txt 2>/dev/null || true
}

# 主函数
main() {
    check_root
    stop_service
    disable_service
    remove_service
    remove_files

    echo "[INFO] 卸载完成"
}

main